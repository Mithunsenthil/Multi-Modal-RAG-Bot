from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .Utils.process_pdf import PDFProcessor
from .Utils.rag_bot import RAGBot
from .Utils.process_doc import DocumentProcessor
from .Utils.process_csv import CSVProcessor  # Import the CSVProcessor class
import os
from django.core.files.storage import default_storage
from django.conf import settings
import pinecone
import base64


# Configuration (move these to Django settings.py for production)
PINECONE_CONFIG = {
    "api_key": "pcsk_7RjTQN_UamNytpW3VLRmZw2LUKN9dM3FQWrCyJZLS2WBSRSpsZPt2yAENrx8Don1j7STgC",
    "index": "rag-bot"
}
GROQ_KEY = "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"
# PDF_PATH = "Data/Data Science Interview.pdf"

# Initialize the RAG system (do this once, not on every request)
# processor = PDFProcessor(
#     pinecone_api_key=PINECONE_CONFIG["api_key"],
#     pinecone_index_name=PINECONE_CONFIG["index"]
# )
# processor.process_pdf(PDF_PATH)  # Process the PDF and upload embeddings to Pinecone

bot = RAGBot(
    groq_api_key=GROQ_KEY,
    pinecone_api_key=PINECONE_CONFIG["api_key"],
    pinecone_index_name=PINECONE_CONFIG["index"]
)


@csrf_exempt
def chat_view(request):
    if request.method == 'POST':
        user_message = request.POST.get('message', '')

        # Retrieve relevant context from Pinecone
        context = bot.retrieve_context(user_message)

        # Generate response using Groq
        response, related_chunks = bot.generate_response(user_message, context, include_related_chunks=True)

        # Prepare the response payload
        payload = {'message': response.strip(), 'related': []}

        for chunk in related_chunks:
            chunk_data = {'type': chunk['type'], 'text': chunk['metadata'].get('text', '')}

            # # Handle images if present
            # if chunk['type'] == 'image':
            #     image_path = chunk['metadata'].get('image_path', None)  # Assume image_path is stored in metadata
            #     if image_path:
            #         # Ensure the image path is correctly mapped to MEDIA_URL
            #         chunk_data['image'] = f"{settings.MEDIA_URL}{image_path}"

            payload['related'].append(chunk_data)

        return JsonResponse(payload)

    return render(request, 'chat.html')

@csrf_exempt
def upload_pdf(request):
    processor = PDFProcessor(
        pinecone_api_key=PINECONE_CONFIG["api_key"],
        pinecone_index_name=PINECONE_CONFIG["index"]
    )
    if request.method == 'POST' and request.FILES.get('pdf_file'):
        # Save the uploaded file temporarily
        uploaded_file = request.FILES['pdf_file']
        file_path = os.path.join(settings.MEDIA_ROOT, uploaded_file.name)
        with default_storage.open(file_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)
        
        try:
            # Process the PDF and upload embeddings to Pinecone
            chunks = processor.process_pdf(file_path)
            
            # Clean up the temporary file
            if default_storage.exists(file_path):
                default_storage.delete(file_path)
            
            # Render the success message
            return render(request, 'upload_pdf.html', {
                'status': 'success',
                'message': f"PDF processed successfully. {len(chunks)} chunks uploaded to Pinecone."
            })
        except Exception as e:
            # Clean up the temporary file in case of error
            if default_storage.exists(file_path):
                default_storage.delete(file_path)
            
            # Render the error message
            return render(request, 'upload_pdf.html', {
                'status': 'error',
                'message': str(e)
            })
    
    # Render the upload form
    return render(request, 'upload_pdf.html')

@csrf_exempt
def upload_doc(request):
    processor = DocumentProcessor(
        pinecone_api_key=PINECONE_CONFIG["api_key"],
        pinecone_index_name=PINECONE_CONFIG["index"]
    )
        
    if request.method == 'POST' and request.FILES.get('doc_file'):
        # Save the uploaded file temporarily
        uploaded_file = request.FILES['doc_file']
        file_path = os.path.join(settings.MEDIA_ROOT, uploaded_file.name)
        with default_storage.open(file_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)
        
        try:
            # Process the DOCX and upload embeddings to Pinecone
            chunks = processor.process_documents(file_path)  # Using the existing method from the processor
            
            # Clean up the temporary file
            if default_storage.exists(file_path):
                default_storage.delete(file_path)
            
            # Render the success message
            return render(request, 'upload_doc.html', {
                'status': 'success',
                'message': f"DOCX processed successfully. {len(chunks)} chunks uploaded to Pinecone."
            })
        except Exception as e:
            # Clean up the temporary file in case of error
            if default_storage.exists(file_path):
                default_storage.delete(file_path)
            
            # Render the error message
            return render(request, 'upload_doc.html', {
                'status': 'error',
                'message': str(e)
            })
    
    # Render the upload form
    return render(request, 'upload_doc.html')


@csrf_exempt
def upload_csv(request):

    processor = CSVProcessor(
        pinecone_api_key=PINECONE_CONFIG["api_key"],
        pinecone_index_name=PINECONE_CONFIG["index"],
        groq_api_key=GROQ_KEY
    )

    if request.method == 'POST' and request.FILES.get('csv_file'):
        # Save the uploaded file temporarily
        uploaded_file = request.FILES['csv_file']
        file_path = os.path.join(settings.MEDIA_ROOT, uploaded_file.name)
        with default_storage.open(file_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)

        try:
            # Process the CSV and upload embeddings to Pinecone
            processor.process_csv(file_path)

            # Clean up the temporary file
            if default_storage.exists(file_path):
                default_storage.delete(file_path)

            # Render the success message
            return render(request, 'upload_csv.html', {
                'status': 'success',
                'message': f"CSV processed successfully and uploaded to Pinecone."
            })
        except Exception as e:
            # Clean up the temporary file in case of error
            if default_storage.exists(file_path):
                default_storage.delete(file_path)

            # Render the error message
            return render(request, 'upload_csv.html', {
                'status': 'error',
                'message': str(e)
            })

    # Render the upload form
    return render(request, 'upload_csv.html')