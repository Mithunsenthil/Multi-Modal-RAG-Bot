import pandas as pd
import pinecone
from pinecone import Pinecone, ServerlessSpec
from sentence_transformers import SentenceTransformer
from groq import Groq


class CSVProcessor:
    def __init__(self, pinecone_api_key, pinecone_index_name,groq_api_key):
        # Initialize Pinecone and Groq
        self.groq_client = Groq(api_key=groq_api_key)
        self.pc = Pinecone(api_key=pinecone_api_key)
        self.index_name = pinecone_index_name

        # Check if index exists, create if not
        if self.index_name not in self.pc.list_indexes().names():
            self.pc.create_index(
                name=self.index_name,
                dimension=768,  # Match the embedding model's output dimension
                metric="cosine",
                spec=ServerlessSpec(
                    cloud='aws',
                    region='us-west-1'  # Correct region for free tier
                )
            )
        self.index = self.pc.Index(self.index_name)

        # Initialize the embedding model
        self.embedding_model = SentenceTransformer('all-mpnet-base-v2')

    def process_csv(self, csv_path):
        """Read a CSV file, summarize the data, and upload to Pinecone"""
        try:
            # Read the CSV file
            df = pd.read_csv(csv_path)
            print(f"Successfully read CSV file: {csv_path}")

            # Summarize the data
            summary = df.head().to_string()
            print(f"CSV Summary:\n{summary}")


            # Construct the prompt for Groq
            prompt = f"""Your are given a sample of a large csv file. summarise it so that the summary will have every 
            information in the csv file.
            Text: {summary}"""

            # Generate the response
            completion = self.groq_client.chat.completions.create(
                model="llama3-70b-8192",
                messages=[
                    {"role": "system", "content": "You are a technical expert. Be concise and accurate.if you dont know dont answer"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0,
                max_tokens=512,
                stop=None
            )
            response = completion.choices[0].message.content.strip()


            # Generate embeddings for the summary
            embedding = self.embedding_model.encode([response])[0].tolist()
            print(f"Generated embedding for the summary.")

            # Prepare the vector for Pinecone
            vector = {
                # "id": csv_path,  # Use the file path as the ID
                "values": embedding,
                "metadata": {
                    "summary": summary+response,
                    "type": "csv",
                    "file_path": csv_path
                }
            }

            # Debug: Print vector details
            print(f"Vector metadata: {vector}")

            # Upsert the vector to Pinecone
            self.index.upsert(vectors=[vector])
            print(f"Successfully uploaded summary for {csv_path} to Pinecone.")

        except Exception as e:
            print(f"Error processing CSV file {csv_path}: {str(e)}")