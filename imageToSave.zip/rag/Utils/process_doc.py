import fitz  # PyMuPDF
import pdfplumber
import pinecone
import re
from sentence_transformers import SentenceTransformer
from PIL import Image
import io
from transformers import BlipProcessor, BlipForConditionalGeneration
from pinecone import Pinecone, ServerlessSpec
import base64  # For encoding/decoding image data
from io import BytesIO
from docx import Document

class DocumentProcessor:
    def __init__(self, pinecone_api_key, pinecone_index_name, chunk_size=500, chunk_overlap=100):
        # Initialize Pinecone
        self.pc = Pinecone(api_key=pinecone_api_key)
        self.index_name = pinecone_index_name

        # Check if index exists, create if not
        if self.index_name not in self.pc.list_indexes().names():
            self.pc.create_index(
                name=self.index_name,
                dimension=768,  # Match the embedding model's output dimension
                metric="cosine",
                spec=ServerlessSpec(
                    cloud='aws',
                    region='us-west-1'  # Correct region for free tier
                )
            )
        self.index = self.pc.Index(self.index_name)

        # Initialize text splitting parameters
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = ["\n\n", "\n", r"(?<!\d)\.(?!\d)", " ", ""]

        # Initialize models
        self.embedding_model = SentenceTransformer('all-mpnet-base-v2')

    def _split_text(self, text):
        """Internal text splitting method"""
        chunks = []
        start = 0
        while start < len(text):
            end = start + self.chunk_size
            if end >= len(text):
                chunks.append(text[start:])
                break

            separator = self.separators[0]
            for sep in self.separators:
                if sep == "":
                    split_point = end
                    break
                matches = list(re.finditer(sep, text[start:end], flags=re.MULTILINE))
                if matches:
                    last_match = matches[-1]
                    split_point = start + last_match.end()
                    separator = sep
                    break

            chunk = text[start:split_point]
            chunks.append(chunk)
            start = split_point - self.chunk_overlap if split_point - self.chunk_overlap > start else split_point

        return chunks

    def extract_content(self, doc_path):
        """Extract text and tables from various document types"""
        text = ""
        tables = []

        if doc_path.endswith('.docx'):
            doc = Document(doc_path)
            for table in doc.tables:
                table_data = []
                for row in table.rows:
                    row_data = [cell.text for cell in row.cells]
                    table_data.append(row_data)
                tables.append(table_data)

            for para in doc.paragraphs:
                text += para.text + "\n"

        elif doc_path.endswith('.txt'):
            with open(doc_path, 'r', encoding='utf-8') as file:
                text = file.read()

        # Add more document types as needed

        return text, tables

    def process_documents(self, doc_path):
        """Full document processing pipeline"""
        text, tables = self.extract_content(doc_path)

        # Prepare table chunks
        table_chunks = []
        for i, table in enumerate(tables):
            if table:
                table_text = ""
                for row in table:
                    if row:
                        cleaned_row = [str(cell) if cell is not None else "" for cell in row]
                        table_text += "|".join(cleaned_row) + "\n"
                table_chunks.append({"id": f"table_{i}", "text": table_text, "type": "table"})

        # Prepare text chunks
        text_chunks = self._split_text(text)
        text_chunks = [{
            # "id": f"text_{i}", 
            "text": chunk, 
            "type": "text"} for i, chunk in enumerate(text_chunks)]

        # Combine all chunks
        all_chunks = text_chunks + table_chunks

        # Debug: Print the number of chunks
        print(f"Number of chunks: {len(all_chunks)} (Text: {len(text_chunks)}, Tables: {len(table_chunks)})")

        # Generate embeddings for all chunks
        all_texts = [chunk["text"] for chunk in all_chunks]
        embeddings = self.embedding_model.encode(all_texts)

        # Prepare vectors for Pinecone
        vectors = []
        for chunk, embedding in zip(all_chunks, embeddings):
            vector = {
                # "id": chunk["id"],
                "values": embedding.tolist(),
                "metadata": {
                    "text": chunk["text"],
                    "type": chunk["type"]
                }
            }
            vectors.append(vector)

        # Debug: Print vector details
        print(f"Number of vectors to be uploaded: {len(vectors)}")
        print(f"Example vector metadata: {vectors[0]['metadata']}")

        # Upsert vectors to Pinecone
        for i in range(0, len(vectors), 50):
            batch = vectors[i:i+50]
            print(f"Uploading batch {i//100 + 1} with {len(batch)} vectors")
            try:
                response = self.index.upsert(vectors=batch)
                print(f"Batch {i//100 + 1} uploaded successfully")
            except Exception as e:
                print(f"Error upserting batch {i//100 + 1}: {str(e)}")

        return all_chunks