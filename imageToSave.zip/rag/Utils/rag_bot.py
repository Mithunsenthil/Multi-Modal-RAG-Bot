from sentence_transformers import SentenceTransformer
from groq import Groq
from pinecone import Pinecone


class RAGBot:
    def __init__(self, groq_api_key, pinecone_api_key, pinecone_index_name):
        self.groq_client = Groq(api_key=groq_api_key)
        self.embedding_model = SentenceTransformer('all-mpnet-base-v2') 
        
        # Initialize Pinecone
        self.pc = Pinecone(api_key=pinecone_api_key)
        self.index = self.pc.Index(pinecone_index_name)

    def retrieve_context(self, query, top_k=3):
        """Retrieve relevant context from Pinecone, including metadata."""
        query_embedding = self.embedding_model.encode(query).tolist()
        results = self.index.query(
            vector=query_embedding,
            top_k=top_k,
            include_metadata=True
        )
        return results.matches

    def generate_response(self, query, context_matches, include_related_chunks=False):
        """Generate response using Groq and optionally return related chunks."""
        full_context = ""
        related_chunks = []

        for match in context_matches:
            metadata_type = match.metadata.get("type", "")
            metadata_text = match.metadata.get("text", "")

            if metadata_type == "text" or metadata_type == "image":
                # Handle text or image type
                context_str = metadata_text
                full_context += f"Context: {context_str}\n\n"

                # Include related chunks if required
                related_chunks.append({
                    "id": match.id,
                    "type": metadata_type,
                    "metadata": match.metadata,
                })

            elif metadata_type == "csv":
                # Handle CSV type
                csv_prompt = f"""You are given a CSV summary and a user query. Generate a pandas code snippet to satisfy the query.
                CSV Summary: {metadata_text}
                User Query: {query}
                Provide only the pandas code:"""

                code_completion = self.groq_client.chat.completions.create(
                    model="llama3-70b-8192",
                    messages=[
                        {"role": "system", "content": "You are a technical expert. Generate only pandas code to satisfy the query."},
                        {"role": "user", "content": csv_prompt}
                    ],
                    temperature=0,
                    max_tokens=512,
                    stop=None
                )
                pandas_code = code_completion.choices[0].message.content.strip()

                # Execute the pandas code
                try:
                    local_vars = {}
                    exec(pandas_code, {"pd": __import__("pandas")}, local_vars)
                    pandas_output = local_vars.get("result", "No output generated")
                except Exception as e:
                    pandas_output = f"Error executing pandas code: {str(e)}"

                # Combine pandas output with metadata text
                combined_prompt = f"""Context: {metadata_text}
                Pandas Output: {pandas_output}"""
                full_context += combined_prompt + "\n\n"

                # Include related chunks if required
                related_chunks.append({
                    "id": match.id,
                    "type": metadata_type,
                    "metadata": match.metadata,
                    "pandas_output": pandas_output
                })

        # Final Groq API call with the full context
        final_prompt = f"""Answer based on the following context:
        {full_context}
        Question: {query}
        Answer in 2-5 sentences:"""

        final_completion = self.groq_client.chat.completions.create(
            model="llama3-70b-8192",
            messages=[
                {"role": "system", "content": "You are an assistant. You must answer the user query using only the provided context. Be concise and accurate. If there is no relevant context for the user query, respond with 'I am not trained on that topic.' Do not add any unnecessary information - use only the given context. Review your response to ensure it follows the context and is grammatically correct."},
                {"role": "user", "content": final_prompt}
            ],
            temperature=0,
            max_tokens=512,
            stop=None
        )
        final_response = final_completion.choices[0].message.content.strip()

        return final_response, related_chunks


# # Usage
# if __name__ == "__main__":
#     # Configuration
#     PINECONE_CONFIG = {
#         "api_key": "pcsk_7RjTQN_UamNytpW3VLRmZw2LUKN9dM3FQWrCyJZLS2WBSRSpsZPt2yAENrx8Don1j7STgC",
#         "index": "rag-system"
#     }
#     GROQ_KEY = "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"
#     PDF_PATH = "Data/Data Science Interview.pdf"

#     # Process PDF and upload to Pinecone
#     processor = PDFProcessor(
#         pinecone_api_key=PINECONE_CONFIG["api_key"],
#         pinecone_index_name=PINECONE_CONFIG["index"]
#     )
#     processor.process_pdf(PDF_PATH)

#     # Query the RAG system
#     bot = RAGBot(
#         groq_api_key=GROQ_KEY,
#         pinecone_api_key=PINECONE_CONFIG["api_key"],
#         pinecone_index_name=PINECONE_CONFIG["index"]
#     )
#     query = "Explain the main concepts discussed in the document"
#     context_matches = bot.retrieve_context(query)
#     response, related_chunks = bot.generate_response(query, context_matches, include_related_chunks=True)
#     print("Response:", response)
#     print("Related Chunks:", related_chunks)
