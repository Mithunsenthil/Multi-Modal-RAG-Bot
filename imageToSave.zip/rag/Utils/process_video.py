# from sentence_transformers import SentenceTransformer

# def get_text_embedding(input_text: str, model_name: str = 'all-mpnet-base-v2') -> list:
#     """
#     Generate an embedding vector for the given input text using a pre-trained model.

#     Args:
#         input_text (str): The input text to embed.
#         model_name (str): The name of the pre-trained embedding model.

#     Returns:
#         list: The embedding vector for the input text.
#     """
#     # Load the pre-trained embedding model
#     model = SentenceTransformer(model_name)
    
#     # Generate the embedding for the input text
#     embedding = model.encode(input_text)
    
#     return embedding.tolist()

# if __name__ == "__main__":
#     # Example usage
#     input_text = "where did mithun senthil studied ."
#     embedding_vector = get_text_embedding(input_text)
#     print("Embedding Vector:", embedding_vector, "Length:", len(embedding_vector))
import base64

# Read the image and encode it in Base64
with open("Data/color-palette.png", "rb") as imageFile:
    encoded_string = base64.b64encode(imageFile.read())
    print(encoded_string)  # This prints the Base64 encoded string

# Decode the Base64 string and save the image
decoded_image = base64.b64decode(encoded_string)
with open("imageToSave.png", "wb") as fh:
    fh.write(decoded_image)
